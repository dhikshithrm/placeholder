package com.example.its12

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
